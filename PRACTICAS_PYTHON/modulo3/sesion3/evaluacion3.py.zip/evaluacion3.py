# Importar el módulo math 
import math

# Asignar el valor 81 a la variable 'y'
y = 81

# Calcular la raíz cuadrada 
raiz_cuadrada = math.sqrt(y)

# Imprimir el resultado 
print("La raíz cuadrada de", y, "es:", raiz_cuadrada)
