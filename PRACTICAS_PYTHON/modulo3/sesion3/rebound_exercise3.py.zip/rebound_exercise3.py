# Asignar el valor 20 a la variable 'a'
a = 20

# Asignar el valor 30 a la variable 'b'
b = 30

# Multiplicación de 'a' * 'b'
resultado = a * b

# Imprimir el resultado 
print("El resultado de la multiplicación es:", resultado)
