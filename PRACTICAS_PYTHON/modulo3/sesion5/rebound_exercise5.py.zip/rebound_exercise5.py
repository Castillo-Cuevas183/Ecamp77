# Importar el módulo math 
import math

# Asignar el número del que queremos calcular el factorial
numero = 10

# Calcular el factorial usando la función factorial del módulo math
factorial = math.factorial(numero)

# Imprimir el resultado del factorial
print("El factorial de", numero, "es:", factorial)
