numeros = [1,2,3,4,5,6,7,8,9,10]

for i in range (10):
    if numeros[i] % 2 == 0:
        print(f"{numeros[i]} es par")
    else:
        print(f"{numeros[i]} es impar")
    
        
