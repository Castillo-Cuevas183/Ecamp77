# Crear diccionarios con los datos personales de tres personas
persona_1 = {"nombre": "Antonio", "apellido": "Jara", "teléfono": "123456789"}
persona_2 = {"nombre": "Marcelino", "apellido": "Nuñez", "teléfono": "2345678912"}
persona_3 = {"nombre": "Jorge", "apellido": "Inostroza", "teléfono": "456789123"}

# Crear una lista que almacene los diccionarios
lista_personas = [persona_1, persona_2, persona_3]

# Imprimir la lista en pantalla
print(lista_personas)
