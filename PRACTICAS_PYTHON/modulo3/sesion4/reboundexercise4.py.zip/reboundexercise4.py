# Crear una variable con el número 8
numero_ocho = 8

# Crear una variable con el número 10.5
numero_decimal = 10.5

# Crear una variable con la palabra "ejercicio"
ejercicio = "ejercicio"

# Crear un set que contenga las variables anteriores
mi_set = {numero_ocho, numero_decimal, ejercicio}

# Crear una lista que contenga el set y una variable con el valor lógico False
mi_lista = [mi_set, False]

# Imprimir la lista en pantalla
print(mi_lista)
