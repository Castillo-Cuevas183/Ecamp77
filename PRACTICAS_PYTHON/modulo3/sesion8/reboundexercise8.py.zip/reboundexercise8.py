mi_lista = [5, 20, 15, 20, 25, 50, 20, 5, 18, 15]

mi_lista = list(set(mi_lista))
mi_lista.sort()

print(mi_lista)

# Output: [5, 15, 18, 20, 25, 50]