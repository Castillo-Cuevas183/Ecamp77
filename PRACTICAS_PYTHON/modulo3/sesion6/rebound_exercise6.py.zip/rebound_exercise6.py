#Definir número
num = -10


#Comprobar si el número es cero, positivo o negativo
if num==0:
    print("El número es cero")
elif num>0:
    print("El número es positivo")
else:
    print("El número es negativo")