# Asignar los tres números a variables
a = 1908
b = 1980
c = 1890

# Crear una lista con los números
numeros = [a, b, c]

# Ordenar la lista en orden descendente (de mayor a menor)
numeros.sort(reverse=True)

# Imprimir los números en orden de mayor a menor
print("Los números ordenados de mayor a menor son:", numeros)
