import math  # Paso 1: Importar el módulo math

y=81

# Paso 2: Utilizar la función math.sqrt() para calcular la raíz cuadrada de y
raiz_cuadrada = math.sqrt(y)

print(raiz_cuadrada)

